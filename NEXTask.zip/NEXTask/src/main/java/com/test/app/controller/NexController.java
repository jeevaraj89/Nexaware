package com.test.app.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.test.app.dto.UserDTO;
import com.test.app.entity.Address;
import com.test.app.entity.User;
import com.test.app.repo.UserRepository;

//@RestController
@Controller
public class NexController {

	@Autowired
	UserRepository userRepository;
	
	@Autowired
	private MongoTemplate mongoTemplate;

	/*
	 * list all saved user
	 * @param 
	 * return list employee details
	 */
	@GetMapping(value= {"/","/view"})
    public String viewUser(Model model) {
		List<User> list = userRepository.findAll();
        List<UserDTO> lstUserDto = new ArrayList<>();
        for(User usr : list) {
        	UserDTO usrDto = new UserDTO(usr.getId(),usr.getName(),usr.getEmail(),usr.getMobile(),usr.getAddress());
        	lstUserDto.add(usrDto);
        }
	    model.addAttribute("listEmployee", lstUserDto);
	    return "view";
    }
	
	/*
	 * create user 
	 * @param 
	 * 
	 */
	@GetMapping("/create")
    public String creatUser(Model model) {
	    return "create";
    }
	
	/*
	 * create user details
	 * @param UserDTO(single user with multiple address)
	 * return saved entity
	 * 
	 */
	@PostMapping("/api/saveUser")
    public ResponseEntity<User> saveUser(@RequestBody UserDTO userDto) {
		User usr = userRepository.findByMobile(userDto.getMobile());
		if(usr == null) {
			User user = new User(userDto.getName(),userDto.getMobile(),userDto.getEmail(),userDto.getAddress());
			for(Address adrs: userDto.getAddress()) {
				adrs.setId(ObjectId.get().toString());
			}
	       User usrs = userRepository.save(user);
	       return new ResponseEntity<User>(usrs, new HttpHeaders(), HttpStatus.OK);
		}else {
			return null;
		}
    }
	
	/*
	 * Edit user page
	 * 
	 */
	@GetMapping("/edit")
    public String editUserinfo(Model model) {
	    return "edit";
    }
	
	/*
	 * Edit user page
	 * @param user object id
	 * return UserDto with multipel user address
	 * 
	 */
	@GetMapping("/edit/{id}")
    public String editUser(@PathVariable(name = "id") String id,RedirectAttributes redirectAttributes) {
		Optional<User> user = userRepository.findById(id);
		if(user.isPresent()) {
			User usr = user.get();
			UserDTO usrDto = new UserDTO(usr.getId(),usr.getName(),usr.getEmail(),usr.getMobile(),usr.getAddress());
			redirectAttributes.addFlashAttribute("user", usrDto);
		}	    
	    return "redirect:/edit";
    }
	
	/*
	 * User to get user address details
	 * @param user object id
	 * return User entity
	 */
	@GetMapping(value="/getAddress")
    public @ResponseBody void getUserAddress(@RequestParam("id")String id,HttpServletResponse response,Model model) throws IOException {
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/json");
		Optional<User> list = userRepository.findById(id);
		if(list.isPresent())
			response.getWriter().write(new Gson().toJson(list.get()));
    }
	
	/*
	 * Delete employee fully
	 * @param user object id
	 * return view page
	 * 
	 */
	@GetMapping("/deleteUser/{id}")
    public String deleteUser(@PathVariable("id")String uid) {
		userRepository.deleteById(uid);
		return "redirect:/view";
    }
	
	/*
	 * Delete user address only
	 * @param User object and address object
	 * 
	 */
	@GetMapping("/deleteAdress")
    public ResponseEntity<User> deleteAddress(@RequestParam("uid")String uid,@RequestParam("id")String id) {
		final Update update = new Update().pull("address",
				Query.query(Criteria.where("id").is(id)));
		mongoTemplate.updateMulti(new Query(Criteria.where("id").is(uid)), update,
				User.class);
        
        return new ResponseEntity<User>(new User(), new HttpHeaders(), HttpStatus.OK);
    }
	
	/*
	 * Update employee and emplyee address
	 * @param UserDTO
	 * return user entity
	 * 
	 */
	@PutMapping("/updateUser")
    public ResponseEntity<User> updateUser(@RequestBody UserDTO userDto,Model model) {
		List<User> usrLst = userRepository.findAll();
		
		//checking employee mobile with other user
		for(User usr : usrLst) {
			if(usr.getMobile().equals(userDto.getMobile())) {
				if(!usr.getId().equalsIgnoreCase(userDto.getId())) {
					return null;
				}
			}
		}
		Optional<User> user = userRepository.findById(userDto.getId());
		User uuser = null;
		if(user.isPresent()) {
			User usr = new User(userDto.getId(),userDto.getName(),userDto.getMobile(),userDto.getEmail(),userDto.getAddress());
			uuser = userRepository.save(usr);
		}
		return new ResponseEntity<User>(uuser, new HttpHeaders(), HttpStatus.OK);
    }
	

	/*@GetMapping("/api/listAllUser")
    public ResponseEntity<List<UserDTO>> getAllEmployees() {
        List<User> list = userRepository.findAll();
        List<UserDTO> lstUserDto = new ArrayList<>();
        for(User usr : list) {
        	UserDTO usrDto = new UserDTO(usr.getId(),usr.getName(),usr.getEmail(),usr.getMobile(),usr.getAddress());
        	lstUserDto.add(usrDto);
        }
        return new ResponseEntity<List<UserDTO>>(lstUserDto, new HttpHeaders(), HttpStatus.OK);
    }*/
}
