package com.test.app.repo;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.test.app.entity.User;

@Repository
public interface UserRepository extends MongoRepository<User,String> {

	User findByMobile(String mobile);

}
